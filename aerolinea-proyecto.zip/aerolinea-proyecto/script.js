document.addEventListener("DOMContentLoaded", () => {
    
    // ==========================================
    // 1. FUNCIONALIDAD DEL BUSCADOR DE VUELOS
    // ==========================================
    const searchForm = document.querySelector(".search-form");

    if (searchForm) {
        searchForm.addEventListener("submit", (event) => {
            // Evitamos que la página se recargue (comportamiento por defecto del formulario)
            event.preventDefault();

            // Capturamos los valores ingresados por el usuario
            const origen = searchForm.querySelector("input[placeholder='Ciudad o Aeropuerto']").value;
            const destino = searchForm.querySelector("input[placeholder='¿A dónde vas?']").value;
            const fechaSalida = searchForm.querySelector("input[type='date']:nth-of-type(1)").value;
            
            // Buscamos el segundo input de fecha por su posición relativa en el formulario
            const inputsFecha = searchForm.querySelectorAll("input[type='date']");
            const fechaRegreso = inputsFecha[1] ? inputsFecha[1].value : "No especificada";

            // VALIDACIÓN BÁSICA: Controlar que las fechas sean lógicas
            if (fechaRegreso !== "No especificada" && new Date(fechaRegreso) < new Date(fechaSalida)) {
                alert("❌ Error: La fecha de regreso no puede ser anterior a la fecha de salida.");
                return; // Detiene la ejecución si hay un error
            }

            // SIMULACIÓN DE BÚSQUEDA
            // En un entorno real, aquí enviarías los datos a un servidor o API
            alert(`✈️ Buscando vuelos disponibles...\n\n📍 Origen: ${origen}\n📍 Destino: ${destino}\n📅 Salida: ${fechaSalida}\n📅 Regreso: ${fechaRegreso}`);
        });
    }

    // ==========================================
    // 2. FUNCIONALIDAD DEL BOTÓN INICIAR SESIÓN
    // ==========================================
    const btnLogin = document.querySelector(".btn-login");

    if (btnLogin) {
        btnLogin.addEventListener("click", () => {
            // Simulación de redirección o apertura de un formulario de Login
            const email = prompt("Por favor, introduce tu correo electrónico institucional:");
            
            if (email) {
                alert(`¡Bienvenido! Se ha enviado un código de acceso a: ${email}`);
            }
        });
    }
});
document.addEventListener("DOMContentLoaded", () => {
    let descuentoAplicado = 0; // Guardará el porcentaje de descuento activo

    // ==========================================
    // FUNCIONALIDAD DEL BOTÓN APLICAR CUPÓN
    // ==========================================
    const btnApplyCoupon = document.getElementById("btn-apply-coupon");
    const couponInput = document.getElementById("coupon-input");

    if (btnApplyCoupon && couponInput) {
        btnApplyCoupon.addEventListener("click", () => {
            const codigo = couponInput.value.trim().toUpperCase();

            if (codigo === "LOWCOST20") {
                descuentoAplicado = 20;
                alert("🎉 ¡Cupón aplicado con éxito! Se aplicará un 20% de descuento en tus resultados.");
                couponInput.style.borderColor = "#2f855a"; // Cambia el borde a verde si es válido
                couponInput.disabled = true; // Desactiva el input para que no lo vuelva a intentar
                btnApplyCoupon.disabled = true;
                btnApplyCoupon.style.backgroundColor = "#2f855a";
                btnApplyCoupon.textContent = "✓";
            } else if (codigo === "") {
                alert("Por favor, ingresa un código de cupón.");
            } else {
                alert("❌ Código inválido. Intenta con LOWCOST20");
                couponInput.style.borderColor = "#e53e3e"; // Borde rojo si falla
            }
        });
    }

    // ==========================================
    // FUNCIONALIDAD DEL BUSCADOR DE VUELOS (ACTUALIZADO)
    // ==========================================
    const searchForm = document.querySelector(".search-form");

    if (searchForm) {
        searchForm.addEventListener("submit", (event) => {
            event.preventDefault();

            const origen = searchForm.querySelector("input[placeholder='Ciudad o Aeropuerto']").value;
            const destino = searchForm.querySelector("input[placeholder='¿A dónde vas?']").value;
            const fechaSalida = searchForm.querySelector("input[type='date']").value;

            // Alerta final mostrando si viaja con descuento o no
            let mensajeExito = `✈️ Buscando vuelos disponibles...\n\n📍 Origen: ${origen}\n📍 Destino: ${destino}\n📅 Salida: ${fechaSalida}`;
            
            if (descuentoAplicado > 0) {
                mensajeExito += `\n\n🎁 ¡Descuento del ${descuentoAplicado}% aplicado en la tarifa final!`;
            }

            alert(mensajeExito);
        });
    }

    // Código previo del botón login...
    const btnLogin = document.querySelector(".btn-login");
    if (btnLogin) {
        btnLogin.addEventListener("click", () => {
            const email = prompt("Por favor, introduce tu correo electrónico:");
            if (email) alert(`¡Bienvenido! Código enviado a: ${email}`);
        });
    }
});